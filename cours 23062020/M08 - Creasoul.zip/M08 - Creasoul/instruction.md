## INSTRUCTIONS
Découverte du responsive

## CSS
- Réalisation de l'exercice en mobil-first
- Utilisation des media queries
- Utilisation du display none
- Largeur limité à 80% maximum en desktop
- Largeur du bloc de gauche en desktop : 70%
- Largeur du bloc de droite en desktop : 30%
- Police utilisés :
    - "PT Sans Narrow"
    - "Open Sans"
- Tailles utilisés :
    - par défaut : 1.6rem
    - h1 : 4rem
    - h2 : 2.4rem
