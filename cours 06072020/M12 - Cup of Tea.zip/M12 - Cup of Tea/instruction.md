Et voilà l'exercice final en intégration ! Ici, aucune instructions sur les propriétés à utiliser : à vous de faire le choix entre le float, le inline-block, le flexbox, le position, etc.

La largeur du site est de 1100px maximum

Taille de police :
    Global :
    - body = 16px
    - h1 : 40px
    - h2 : 25px
    - h3 : 20px

    Page index et listing-product :
    Affichage du prix à 24px

    Page product :
    h3 : 30px
    Affichage du prix à 40px

Transitions :
nav : background qui devient blanc avec une opacité de 20%
btn : opacité qui passe à 75%
"choisissez votre thé" : opacité à 0.5 sauf sur l'image survolé (reste à 1)
